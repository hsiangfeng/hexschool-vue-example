<template>
  <div class="home container">
    <div class="row row-cols-1 row-cols-md-3 g-4">
      <div v-for="item in data" class="card" style="width: 18rem" :key="item.id">
        <img :src="item.image" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">{{ item.title }}</h5>
          <a href="#" class="btn btn-primary" @click.prevent="addtoCar(item)">加入購物車</a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  name: 'Home',
  data() {
    return {
      data: [],
      carData: JSON.parse(localStorage.getItem('carData')) || [],
    };
  },
  methods: {
    getProducts() {
      this.axios.get(`${process.env.VUE_APP_APIPATH}/api/${process.env.VUE_APP_COUSTOMPATH}/products/all`)
        .then((res) => {
          this.data = res.data.products;
        });
    },
    addtoCar(data) {
      this.carData.forEach((item, keys) => {
        if (item.product_id === data.id) {
          let { qty } = item;
          const cache = {
            product_id: data.id,
            qty: qty += 1,
          };
          console.log(this.carData.splice(keys, 1));

          console.log('1', this.carData);
          this.carData.push(cache);
          console.log('2', this.carData);
          localStorage.setItem('carData', JSON.stringify(this.carData));
        }
      });

      if (!this.carData.length) {
        const cartContent = {
          product_id: data.id,
          qty: 1,
        };
        this.carData.push(cartContent);
        localStorage.setItem('carData', JSON.stringify(this.carData));
      }
    },
  },
  created() {
    this.getProducts();
  },
};
</script>
